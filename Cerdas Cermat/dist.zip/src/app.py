#!/usr/bin/env python3

from modules.cli import run

if __name__ == "__main__":
    run()